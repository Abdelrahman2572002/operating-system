//names & IDs:
//عز الدين أحمد صابر 20200325
//عبدالله محسن عبد الحافظ 20200304
//عبد الرحمن رمضان ابو العلا 20200284
//احمد هاني ابراهيم 20200054
public class Producer extends Thread {
    Queue q;
    int N;
    public Producer(Queue q,int N) {
        this.q = q;
        this.N = N;

    }

    public void run() {
        for (int i=2;i<=N;i++) {
            q.add(i);

            try {
               Thread.sleep(10);
            } catch (Exception e) {
            }
        }
    }
}