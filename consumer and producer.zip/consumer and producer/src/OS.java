//names & IDs:
//عز الدين أحمد صابر 20200325
//عبدالله محسن عبد الحافظ 20200304
//عبد الرحمن رمضان ابو العلا 20200284
//احمد هاني ابراهيم 20200054
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class OS extends JFrame{
    public JPanel panalMain;
    private JButton startProducerButton;
    private JTextField input_N;
    private JTextField input_buffer;
    private JTextField input_file;
    private JTextField output_largest;
    private JTextField output_elements;
    private JTextField output_time;
    private JLabel N;
    private JLabel Buffer_Size;
    private JLabel File;
    private JLabel largest;
    private JLabel elements;
    private JLabel time_elapsed;
    private JTextField process;

    public OS() {
        startProducerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String file_name = input_file.getText();

                int size = Integer.parseInt( input_buffer.getText());
                int N = Integer.parseInt( input_N.getText());
                if (size>N || size<1 || N<1){
                    process.setText("UnValid Input");
                }
                else {
                    Queue q = new Queue(size, file_name, N, output_largest, output_elements, output_time);
                    Producer producer = new Producer(q, N);
                    Consumer consumer = new Consumer(q, process);

                    producer.start();

                    consumer.start();
                }
            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}