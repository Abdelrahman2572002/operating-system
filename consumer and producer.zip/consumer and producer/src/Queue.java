import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ArrayBlockingQueue;
import java.io.BufferedWriter;
import org.springframework.util.StopWatch;


public class Queue {
    Main startTime = new Main();
    ArrayBlockingQueue<Integer> queue;
    BufferedWriter writer ;
    String file_name;
    int largest;
    int N;
    JTextField output_time;
    JTextField last;
    boolean finished;
    int count;
    long time;
    JTextField prime_generated;
    int size;
    int x =1;
    int xx=1;
    public Queue(int size, String file_name, int N, JTextField last,JTextField prime_generated,JTextField output_time) {
        this.queue = new ArrayBlockingQueue<>(size);
        this.file_name = file_name;
        this.N = N;
        largest = 0;
        this.last = last;
        finished = false;
        this.prime_generated = prime_generated;
        this.output_time = output_time;
        count = 0;
        this.size=size;
    }
    public boolean isPrime(int n){

        for (int i = 2; i < n; i++)
            if (n % i == 0)
                return false;
        return true;
    }

    public void getLastprime(){
        for(int i =N;i>1;i--){
            if (isPrime(i)) {
                largest = i;
                break;
            }
        }
    }


    public synchronized void add(int n){
        if (isPrime(n)){
            while(!queue.offer(n)){
                try {
                    wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        notify();
    }


    public synchronized void get(){
        getLastprime();
        while(queue.isEmpty()){
            try {
                wait();

            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        try {
            this.writer = new BufferedWriter(new FileWriter(file_name, true));
            if (largest == queue.peek()) {
                last.setText(String.valueOf(largest));
                writer.write(queue.remove() + " , ");
                count++;
                prime_generated.setText(String.valueOf(count));
                writer.close();
                finished = true;
                time = System.nanoTime() - startTime.getTime();
                output_time.setText(String.valueOf(time/1000000) + "ms");

            } else {

                count++;
                if (x== (size)*xx){
                    prime_generated.setText(String.valueOf(count));
                    time = System.nanoTime() - startTime.getTime();
                    output_time.setText(String.valueOf(time/1000000) + "ms");
                    last.setText(queue.peek().toString());
                    xx++;
                }
                writer.write(queue.remove() + " , ");
                x++;
                writer.close();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        notify();
    }
}