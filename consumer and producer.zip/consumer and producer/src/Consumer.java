//names & IDs:
//عز الدين أحمد صابر 20200325
//عبدالله محسن عبد الحافظ 20200304
//عبد الرحمن رمضان ابو العلا 20200284
//احمد هاني ابراهيم 20200054
import javax.swing.*;
public class Consumer extends Thread{

    Queue q;

    JTextField process;

    public Consumer(Queue q, JTextField process) {
        this.q = q;
        this.process = process;

    }

    public void run() {


        while(true){
            q.get();
            if(q.finished){
                process.setText("Finished");
                break;
            }
            try {
                Thread.sleep(10);
            } catch (Exception e) {
            }
        }
    }
}