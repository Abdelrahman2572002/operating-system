//names & IDs:
//عز الدين أحمد صابر 20200325
//عبدالله محسن عبد الحافظ 20200304
//عبد الرحمن رمضان ابو العلا 20200284
//احمد هاني ابراهيم 20200054
import javax.swing.*;
import org.springframework.util.StopWatch;
public class Main {
    long startTime = System.nanoTime();
    public long getTime() {
        return startTime;
    }

    public static void main(String[] args) {
        OS os = new OS();
        os.setContentPane(os.panalMain);
        os.setSize(300,400);
        os.setVisible(true);
        os.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}